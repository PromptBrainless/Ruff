import type { CSSProperties, ReactNode } from "react";
import { Badge } from "@/components/ui/badge";
import { cn } from "../../lib/utils";

export function PropertySection({
  children,
  className,
  title,
  first,
  streamlined,
}: {
  children: ReactNode;
  className?: string;
  /** Labeled section header (§4). When set, renders the uppercase header above the rows. */
  title?: string;
  /** First section drops the top padding on its header. */
  first?: boolean;
  streamlined?: boolean;
}) {
  return (
    <div className={className} data-property-section="true">
      {title ? (
        <div
          data-slot="property-section-label"
          data-streamlined={streamlined || undefined}
          className={cn(
            streamlined
              ? "pb-1 font-mono text-(length:--text-nano) font-normal uppercase tracking-wide text-muted-foreground/70"
              : "text-xs font-semibold uppercase tracking-wide text-muted-foreground pb-1",
            first ? "pt-0" : "pt-3",
          )}
        >
          {title}
        </div>
      ) : null}
      <div className="space-y-0.5">{children}</div>
    </div>
  );
}

export function PropertyRow({
  label,
  children,
  wrap,
}: {
  label: ReactNode;
  children: ReactNode;
  /** Opt-in wrapping for chip-collection rows only (§5). Default rows stay one line. */
  wrap?: boolean;
}) {
  return (
    <div
      className={cn(
        "flex w-full min-w-0 gap-3 py-1",
        wrap ? "items-start" : "items-center",
      )}
      data-property-row="true"
    >
      <span
        className={cn(
          "text-xs text-muted-foreground shrink-0 w-24 truncate",
          wrap && "mt-0.5",
        )}
        data-property-label={typeof label === "string" ? label : undefined}
        title={typeof label === "string" ? label : undefined}
      >
        {label}
      </span>
      <div
        className={cn(
          "flex min-w-0 flex-1 items-center gap-1.5",
          wrap && "flex-col items-start",
        )}
        data-property-value="true"
      >
        {children}
      </div>
    </div>
  );
}

export function PropertyChip({
  children,
  className,
  style,
  title,
}: {
  children: ReactNode;
  className?: string;
  style?: CSSProperties;
  /** Tooltip override for chips whose children are not a bare string. */
  title?: string;
}) {
  return (
    <Badge
      variant="outline"
      // Badge chassis; keep this chip's truncation + normal weight + start alignment.
      className={cn("max-w-full min-w-0 justify-start truncate font-normal", className)}
      style={style}
      title={title ?? (typeof children === "string" ? children : undefined)}
    >
      {children}
    </Badge>
  );
}
