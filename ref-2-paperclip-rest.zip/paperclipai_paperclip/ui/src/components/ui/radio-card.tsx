import * as React from "react";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

export type RadioCardOption = {
  value: string;
  title: string;
  description?: string;
  icon?: React.ReactNode;
  accessibleLabel?: string;
  tooltip?: string;
  /**
   * Disable this one option while its siblings stay live. For a choice the
   * viewer's capabilities forbid: the option stays legible, with its reason in
   * `description` or `tooltip`, instead of vanishing and making the scope
   * unexplained.
   */
  disabled?: boolean;
};

/**
 * Selectable card primitive — a labelled `<button aria-pressed>` with a
 * ring-on-selected treatment. Used by the routine Delivery section (§3.5) and
 * reusable for onboarding / adapter pickers. Render several inside a
 * `<RadioCardGroup>` for roving keyboard nav.
 */
export function RadioCard({
  selected,
  title,
  description,
  icon,
  tooltip,
  className,
  ...props
}: {
  selected: boolean;
  title: string;
  description?: string;
  icon?: React.ReactNode;
  tooltip?: string;
} & Omit<React.ComponentProps<"button">, "title">) {
  return (
    <button
      type="button"
      role="radio"
      aria-checked={selected}
      data-state={selected ? "checked" : "unchecked"}
      className={cn(
        "group relative flex w-full flex-col items-start gap-1 rounded-md border px-4 py-3 text-left transition-colors",
        "motion-safe:transition-(--tp-border-color-background-color) motion-safe:duration-150",
        selected
          ? "border-primary bg-primary/5 ring-1 ring-primary"
          : "border-border hover:border-border hover:bg-accent/40",
        "disabled:cursor-not-allowed disabled:opacity-60",
        className,
      )}
      title={tooltip}
      {...props}
    >
      <div className="flex w-full items-center justify-between gap-2">
        <span className="flex min-w-0 items-center gap-2 text-sm font-medium">
          {icon ? (
            <span
              data-slot="radio-card-icon"
              className="shrink-0 text-muted-foreground"
              aria-hidden="true"
            >
              {icon}
            </span>
          ) : null}
          <span>{title}</span>
        </span>
        {selected ? <Check className="h-4 w-4 shrink-0 text-primary" /> : null}
      </div>
      {description ? (
        <span className="text-xs text-muted-foreground">{description}</span>
      ) : null}
    </button>
  );
}

export function RadioCardGroup({
  value,
  onValueChange,
  options,
  ariaLabel,
  disabled,
  className,
}: {
  value: string;
  onValueChange: (value: string) => void;
  options: RadioCardOption[];
  ariaLabel: string;
  disabled?: boolean;
  className?: string;
}) {
  const handleKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    if (disabled) return;
    const idx = options.findIndex((option) => option.value === value);

    let step: number | null = null;
    if (event.key === "ArrowDown" || event.key === "ArrowRight") {
      step = 1;
    } else if (event.key === "ArrowUp" || event.key === "ArrowLeft") {
      step = -1;
    }
    if (step === null) return;
    event.preventDefault();
    // Step over disabled options rather than landing on one: arrowing onto a
    // choice the viewer cannot make would select it.
    const len = options.length;
    for (let hop = 1; hop <= len; hop++) {
      const next = idx === -1 ? (step === 1 ? hop - 1 : len - hop) : (((idx + step * hop) % len) + len) % len;
      const candidate = options[next];
      if (!candidate.disabled) {
        onValueChange(candidate.value);
        event.currentTarget.querySelectorAll<HTMLButtonElement>('[role="radio"]')[next]?.focus();
        return;
      }
    }
  };

  return (
    <div
      role="radiogroup"
      aria-label={ariaLabel}
      className={cn("grid gap-2", className)}
      onKeyDown={handleKeyDown}
    >
      {options.map((option) => (
        <RadioCard
          key={option.value}
          selected={option.value === value}
          title={option.title}
          description={option.description}
          icon={option.icon}
          tooltip={option.tooltip}
          aria-label={option.accessibleLabel}
          disabled={disabled || option.disabled}
          tabIndex={option.value === value || (!options.some(item => item.value === value && !item.disabled) && option === options.find(item => !item.disabled)) ? 0 : -1}
          onClick={() => onValueChange(option.value)}
        />
      ))}
    </div>
  );
}
