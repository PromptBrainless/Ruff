# Referenz-Repos (Kopie, shallow, ohne .git/Binärdateien/Lockfiles/Dateien >300 KB)
Quelle jeweils https://github.com/<owner>/<repo> (Ordnername = owner_repo)
- paperclipai/paperclip (ohne tests, ui/storybook, packages/paperclip-runner, maps; ZIP 1 = server/, ZIP 2 = Rest)
- teamclawai/teamclaw
- cobusgreyling/grok-bot-templates
- sindresorhus/awesome
- MewPurPur/GodSVG
- google/model-viewer
- storytold/vectorcraft (ZIP 3)
- ishandutta2007/Awesome-Collaborative-Workspace
- MIJUUUUU/allink-collaboration-workspace
- minkoi007cs/collaborative_workspace
- Agent-A345/CoLab
- YasirAwan4831/rt-collaborative-doc-editor-fs3
- Safiullah-Rahu/CSV-AI
Lizenzen der Einzelrepos beachten (LICENSE-Dateien liegen jeweils bei).
